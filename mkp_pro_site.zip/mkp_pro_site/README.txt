# MKP — Markhor of Pakistan (Single‑Page Site)

Files:
- `index.html`
- `assets/mkp-logo.png` (your provided logo)

## Deploy on GitHub Pages
1) Create a GitHub repo (e.g., `mkp-site`).
2) Upload `index.html` and the `assets/` folder.
3) In **Settings → Pages**: Source = Deploy from a branch, Branch = `main` (root). Save.
4) Your site will appear at `https://<username>.github.io/mkp-site/`.

## Deploy on Netlify (drag & drop)
1) Go to https://app.netlify.com/drop
2) Drop this whole folder.
3) Copy the URL Netlify gives you.

## After Launch
- Replace dummy links with your real Telegram/Twitter and add the contract/DEX URL to the **Buy MKP** button.